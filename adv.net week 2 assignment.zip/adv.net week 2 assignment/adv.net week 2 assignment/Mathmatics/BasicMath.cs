﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mathematics
{
    public class BasicMath
    {
        public int Add(int num1, int num2)
        {
            return num1 + num2;
        }


        public int Subtract(int num1, int num2)
        {
            return num1 - num2;
        }


        public int Multiply(int num1, int num2)
        {
            return (num1 * num2);
        }


        public int Divide(int num1, int num2)
        {
            return (num1 / num2);
        }
    }
	public class AdvMath
	{
		public double CalculateArea(double height, double width)
		{
			return height * width;
		}

		public double CalculateAverage(List<double> values)
		{
			if (values == null || values.Count == 0)
				throw new ArgumentException("cannot be null or emptty");

			return values.Average();
		}

		public double ValueSquared(double value)
		{
			return value * value;
		}

		public double CalculatePythagoreanTheorem(double a, double b)
		{
			return Math.Sqrt(ValueSquared(a) + ValueSquared(b));
		}
	}
}
