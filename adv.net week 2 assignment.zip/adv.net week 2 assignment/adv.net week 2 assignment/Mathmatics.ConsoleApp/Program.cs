﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mathematics.ConsoleApp
{
	internal class Program
	{
		static void Main(string[] args)
		{
			try
			{
				string operation;
				double operand1 = 0, operand2 = 0;
				double result;

				ValidateArguments(args, out operation, out operand1, out operand2);

				BasicMath basicMath = new BasicMath();
				AdvMath advMath = new AdvMath();
				string operationDesc;

				switch (operation)
				{
					//case "+":
					//	result = basicMath.Add(operand1, operand2);
					//	operationDesc = "plus";
					//	Console.WriteLine($"{operand1} {operationDesc} {operand2} is equal to {result}");
					//	break;
					//case "-":
					//	result = basicMath.Subtract(operand1, operand2);
					//	operationDesc = "minus";
					//	Console.WriteLine($"{operand1} {operationDesc} {operand2} is equal to {result}");
					//	break;
					//case "*":
					//	result = basicMath.Multiply(operand1, operand2);
					//	operationDesc = "multiplied by";
					//	Console.WriteLine($"{operand1} {operationDesc} {operand2} is equal to {result}");
					//	break;
					//case "/":
					//	result = basicMath.Divide(operand1, operand2);
					//	operationDesc = "divided by";
					//	Console.WriteLine($"{operand1} {operationDesc} {operand2} is equal to {result}");
					//	break;
					case "area":
						result = advMath.CalculateArea(operand1, operand2);
						operationDesc = "area";
						Console.WriteLine($"{operand1} {operationDesc} {operand2} is equal to {result}");
						break;

					case "average":
						result = advMath.CalculateAverage(new List<double> { operand1, operand2 });
						operationDesc = "average";
						Console.WriteLine($"{operand1} {operationDesc} {operand2} is equal to {result}");

						break;

					case "square":
						result = advMath.ValueSquared(operand1);
						operationDesc = "square";
						Console.WriteLine($"{operand1} {operationDesc} {operand2} is equal to {result}");
						break;

					case "hypotenuse":
						result = advMath.CalculatePythagoreanTheorem(operand1, operand2);
						operationDesc = "hypotenuse";
						Console.WriteLine($"{operand1} {operationDesc} {operand2} is equal to {result}");
						break;

					default:
						throw new ArgumentException("Invalid operation. Use: area, average, square, hypotenuse.");
				}
				Console.WriteLine($"The {operationDesc} is: {result}");
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Error: {ex.Message}");
			}

		}

		static void ValidateArguments(string[] args, out string operation, out double operand1, out double operand2)
		{
			if (args.Length < 2)
				throw new ArgumentException("Not enough arguments. Usage: <operation> <num1> [num2]");

			operation = args[0].ToLower();
			if (!double.TryParse(args[1], out operand1))
				throw new ArgumentException("First number is invalid.");

			operand2 = 0;
			if (operation != "square")
			{
				if (args.Length < 3 || !double.TryParse(args[2], out operand2))
					throw new ArgumentException("Second number is invalid.");
			}
		}

	}
}
