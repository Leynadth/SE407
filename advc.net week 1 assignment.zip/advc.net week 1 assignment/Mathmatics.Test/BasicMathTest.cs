namespace Mathmatics.Test
{
    //public class BasicMathTest : IClassFixture<BasicMathTestFixture>
    //{
    //    private BasicMathTestFixture _fixture;

    //    public BasicMathTest(BasicMathTestFixture fixture)
    //    {
    //        _fixture = fixture;
    //    }


    //    [Theory]
    //    [InlineData(5, 3, 8)]
    //    [InlineData(10, 5, 15)]
    //    [InlineData(2, 2, 4)]
    //    [InlineData(10000, 567, 10567)]
    //    public void TestAddTwoNumbers(int num1, int num2, int expectedResults)
    //    {
    //        int result = _fixture.TestObject.Add(num1, num2);
    //        Assert.Equal(expectedResults, result);
    //    }


    //    [Fact]
    //    public void TestSubtractTwoNumbers()
    //    {
    //        int result = _fixture.TestObject.Subtract(5, 3);
    //        Assert.Equal(2, result);
    //    }


    //    [Fact]
    //    public void TestMultiplyTwoNumbers()
    //    {
    //        int result = _fixture.TestObject.Multiply(5, 3);
    //        Assert.Equal(15, result);
    //    }


    //    [Fact]
    //    public void TestDivideTwoNumbers()
    //    {
    //        int result = _fixture.TestObject.Divide(6, 3);
    //        Assert.Equal(2, result);
    //    }
    //}

	public class AdvMathTest : IClassFixture<AdvMathTestFixture>
	{
		private readonly AdvMathTestFixture _fixture;

		public AdvMathTest(AdvMathTestFixture fixture)
		{
			_fixture = fixture;
		}

		[Fact]
		public void TestCalculateArea()
		{
			double result = _fixture.TestObject.CalculateArea(5, 8);
			Assert.Equal(40, result);
		}

		[Fact]
		public void TestCalculateAverage()
		{
			double result = _fixture.TestObject.CalculateAverage(new System.Collections.Generic.List<double> { 1, 2, 3, 4, 5 });
			Assert.Equal(3, result);
		}

		[Fact]
		public void TestValueSquared()
		{
			double result = _fixture.TestObject.ValueSquared(5);
			Assert.Equal(25, result);
		}

		[Fact]
		public void TestCalculatePythagoreanTheorem()
		{
			double result = _fixture.TestObject.CalculatePythagoreanTheorem(3, 4);
			Assert.Equal(5, result);
		}
	}
}